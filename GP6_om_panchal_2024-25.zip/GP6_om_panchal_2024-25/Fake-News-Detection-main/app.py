import streamlit as st
import joblib
import numpy as np
import re
import requests
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
import os

# Load datasets (replace with your actual paths)
try:
    dataset1 = pd.read_csv(
        r"C:\Users\ASUS\Downloads\Fake-News-Detection-main\Fake-News-Detection-main\True_new.csv"
    )  # Assumes a column named 'text'
    dataset2 = pd.read_csv(
        r"C:\Users\ASUS\Downloads\Fake-News-Detection-main\Fake-News-Detection-main\fake_news.csv"
    )  # Assumes a column named 'text'
except FileNotFoundError:
    st.error("Dataset files not found. Please provide valid dataset paths.")
    st.stop()

# API keys
NEWS_API_KEY = "64cf9c4355a747988a5bee3f649c05ca"

# Set page configuration
st.set_page_config(
    page_title="Health Misinformation Detector",
    page_icon="🩺",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Enhanced Custom CSS with animations
st.markdown(
    """
    <style>
    body {
        background: linear-gradient(135deg, #1a1a1a 0%, #2c2c2c 100%);
        color: #ffffff;
        font-family: 'Arial', sans-serif;
    }
    .title {
        font-size: 3em;
        font-weight: 700;
        text-align: center;
        color: #00d4ff;
        text-shadow: 0 0 10px rgba(0, 212, 255, 0.7);
        animation: fadeIn 1.5s ease-in-out;
    }
    .subtitle {
        font-size: 1.3em;
        text-align: center;
        color: #b0b0b0;
        margin-bottom: 30px;
        animation: slideUp 1s ease-in-out;
    }
    .result-box {
        padding: 15px;
        border-radius: 10px;
        margin: 15px 0;
        font-size: 1.2em;
        text-align: center;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
        animation: popIn 0.5s ease-out;
    }
    .real-result {
        background: linear-gradient(90deg, #28a745, #34c759);
        color: #ffffff;
    }
    .fake-result {
        background: linear-gradient(90deg, #dc3545, #ff5768);
        color: #ffffff;
    }
    .warning-result {
        background: linear-gradient(90deg, #ffc107, #ffd54f);
        color: #1a1a1a;
    }
    .suggested-links {
        margin-top: 15px;
        color: #d0d0d0;
        font-size: 1.1em;
        animation: fadeIn 1s ease-in-out;
    }
    .suggested-links a {
        color: #00d4ff;
        text-decoration: none;
        transition: color 0.3s ease;
    }
    .suggested-links a:hover {
        color: #ffeb3b;
        text-decoration: underline;
    }
    .stTextArea textarea, .stTextInput input {
        background-color: #333333;
        color: #ffffff;
        border: 2px solid #00d4ff;
        border-radius: 8px;
        padding: 10px;
        transition: border-color 0.3s ease;
    }
    .stTextArea textarea:focus, .stTextInput input:focus {
        border-color: #ffeb3b;
        outline: none;
    }
    .stButton button {
        background: linear-gradient(90deg, #00d4ff, #007bff);
        color: white;
        border: none;
        border-radius: 25px;
        padding: 12px 25px;
        font-size: 1.1em;
        font-weight: bold;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        box-shadow: 0 4px 15px rgba(0, 212, 255, 0.4);
    }
    .stButton button:hover {
        transform: translateY(-3px);
        box-shadow: 0 6px 20px rgba(0, 212, 255, 0.6);
        background: linear-gradient(90deg, #007bff, #00d4ff);
    }
    .sidebar .sidebar-content {
        background: #252525;
        border-right: 2px solid #00d4ff;
    }
    .footer {
        text-align: center;
        color: #b0b0b0;
        margin-top: 50px;
        font-size: 0.9em;
        animation: fadeIn 2s ease-in-out;
    }
    @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
    }
    @keyframes slideUp {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
    }
    @keyframes popIn {
        from { transform: scale(0.9); opacity: 0; }
        to { transform: scale(1); opacity: 1; }
    }
    </style>
    """,
    unsafe_allow_html=True,
)

# Sidebar content
with st.sidebar:
    st.markdown(
        '<h2 style="color: #00d4ff; text-shadow: 0 0 5px rgba(0, 212, 255, 0.5);">About This Tool</h2>',
        unsafe_allow_html=True,
    )
    st.markdown(
        """
        This Health Misinformation Detector leverages machine learning to verify news articles. 
        Powered by logistic regression and TF-IDF vectorization, it’s your shield against health misinformation.

        **How to Use:**
        - Paste an article or generate a new one
        - Hit 'Analyze Article'
        - Get results with related sources
        """,
        unsafe_allow_html=True,
    )
    st.markdown("---")
    st.markdown(
        '<p style="color: #b0b0b0;"></p>',
        unsafe_allow_html=True,
    )


# Function to train and save the Logistic Regression model
def train_and_save_model():
    # Assume 'text' column contains the article text and add labels (1 for true, 0 for fake)
    dataset1["label"] = 1
    dataset2["label"] = 0

    # Combine datasets
    data = pd.concat([dataset1[["text", "label"]], dataset2[["text", "label"]]])
    X = data["text"]
    y = data["label"]

    # Split into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    # Initialize and fit the TF-IDF vectorizer
    vectorizer = TfidfVectorizer(max_features=5000, stop_words="english")
    X_train_vectorized = vectorizer.fit_transform(X_train)
    X_test_vectorized = vectorizer.transform(X_test)

    # Initialize and train the Logistic Regression model
    model = LogisticRegression(max_iter=1000)
    model.fit(X_train_vectorized, y_train)

    # Save the model and vectorizer
    joblib.dump(
        model,
        r"C:\Users\ASUS\Downloads\Fake-News-Detection-main\Fake-News-Detection-main\lr_model.jb",
    )
    joblib.dump(
        vectorizer,
        r"C:\Users\ASUS\Downloads\Fake-News-Detection-main\Fake-News-Detection-main\vectorizer.jb",
    )

    return model, vectorizer


# Load or train the model and vectorizer
if not os.path.exists(
    r"C:\Users\ASUS\Downloads\Fake-News-Detection-main\Fake-News-Detection-main\lr_model.jb"
) or not os.path.exists(
    r"C:\Users\ASUS\Downloads\Fake-News-Detection-main\Fake-News-Detection-main\vectorizer.jb"
):
    st.info("Training new model and vectorizer...")
    model, vectorizer = train_and_save_model()
    st.success("Model and vectorizer trained and saved successfully!")
else:
    try:
        vectorizer = joblib.load(
            r"C:\Users\ASUS\Downloads\Fake-News-Detection-main\Fake-News-Detection-main\vectorizer.jb"
        )
        model = joblib.load(
            r"C:\Users\ASUS\Downloads\Fake-News-Detection-main\Fake-News-Detection-main\lr_model.jb"
        )
    except FileNotFoundError:
        st.error("Model or vectorizer file not found. Training new ones...")
        model, vectorizer = train_and_save_model()


# Function to fetch related articles
def fetch_related_articles(keywords):
    url = "https://newsapi.org/v2/everything"
    params = {
        "q": " ".join(keywords),
        "apiKey": NEWS_API_KEY,
        "language": "en",
        "sortBy": "relevancy",
        "pageSize": 3,
    }
    try:
        response = requests.get(url, params=params)
        response.raise_for_status()
        data = response.json()
        if data.get("status") == "ok" and data.get("articles"):
            articles = data["articles"]
            return [
                {
                    "title": article["title"],
                    "url": article["url"],
                    "description": article.get(
                        "description", "No description available."
                    ),
                }
                for article in articles
            ]
        else:
            return [
                {
                    "title": "No related articles found.",
                    "url": "#",
                    "description": "N/A",
                }
            ]
    except requests.RequestException as e:
        st.error(f"Error fetching related articles: {e}")
        return [
            {
                "title": "Error fetching related articles.",
                "url": "#",
                "description": "N/A",
            }
        ]


# Function to generate a new article
def generate_new_article():
    text1 = dataset1["text"].sample(1).iloc[0]
    text2 = dataset2["text"].sample(1).iloc[0]
    combined_text = f"{text1} {text2}"
    return combined_text


# Function to validate input text
def is_valid_article(text):
    # Check if text is too short or contains only random characters
    if len(text) < 20:  # Increased minimum length requirement
        return False
    # Check for excessive non-alphabetic characters
    non_alpha_ratio = sum(1 for c in text if not c.isalpha() and not c.isspace()) / len(
        text
    )
    if non_alpha_ratio > 0.3:  # More than 30% non-alphabetic characters
        return False
    # Check if at least 3 valid English words are present
    words = re.findall(r"\b\w{3,}\b", text.lower())
    valid_word_count = sum(
        1
        for word in words
        if word
        in [
            "health",
            "disease",
            "vaccine",
            "study",
            "research",
            "medicine",
            "cancer",
            "heart",
            "meditation",
            "efficacy",
            "treatment",
            "therapy",
            "virus",
            "approval",
            "rating",
            "president",
            "news",
            "media",
            "coverage",
            "obama",
            "trump",
            "said",
            "report",
            "found",
            "new",
            "data",
            "test",
            "case",
        ]
        or any(c.isalpha() for c in word if len(word) > 4)
    )
    return valid_word_count >= 3


# Main content container
st.markdown(
    '<h1 class="title">Health Misinformation Detector</h1>', unsafe_allow_html=True
)
# Removed the line: st.markdown('<p class="subtitle">Unmask the Truth with AI-Powered Analysis</p>', unsafe_allow_html=True)

# Input and analysis section
col1, col2 = st.columns([2, 1])
with col1:
    if "generated_article" not in st.session_state:
        st.session_state.generated_article = ""

    inputn = st.text_area(
        "Article Text",
        value=st.session_state.generated_article,
        placeholder="Paste your article here or generate a new one...",
        height=300,
        key="article_text",
    )

with col2:
    st.markdown("<div style='margin-top: 20px;'></div>", unsafe_allow_html=True)
    if st.button("Generate New Article"):
        new_article = generate_new_article()
        st.session_state.generated_article = new_article
        st.rerun()

    if st.button("Analyze Article"):
        if inputn.strip():  # Changed to only check inputn
            with st.spinner("Analyzing..."):
                text_to_analyze = inputn

                # Validate the input text
                if not is_valid_article(text_to_analyze):
                    st.error(
                        "Please enter a valid article. The input appears to be random or incomplete."
                    )
                else:
                    transform_input = vectorizer.transform([text_to_analyze])
                    prediction = model.predict(transform_input)[0]
                    proba = model.predict_proba(transform_input)[0]
                    confidence = max(proba) * 100

                    text_lower = text_to_analyze.lower()
                    keywords = re.findall(r"\b\w{4,}\b", text_lower)
                    health_keywords = [
                        kw
                        for kw in keywords
                        if kw
                        in [
                            "health",
                            "disease",
                            "vaccine",
                            "study",
                            "research",
                            "medicine",
                            "cancer",
                            "heart",
                            "meditation",
                            "efficacy",
                            "treatment",
                            "therapy",
                            "virus",
                            "approval",
                            "rating",
                            "president",
                            "news",
                            "media",
                            "coverage",
                            "obama",
                            "trump",
                        ]
                    ]
                    if not health_keywords:
                        health_keywords = (
                            keywords[:3] if len(keywords) >= 3 else keywords
                        )

                    suggested_articles = fetch_related_articles(health_keywords)

                    if prediction == 1:
                        result_msg = f"✅ Real News ({confidence:.2f}% confidence)"
                        st.markdown(
                            f'<div class="result-box real-result">{result_msg}</div>',
                            unsafe_allow_html=True,
                        )
                        st.balloons()
                        st.success("Credible article detected!")
                    else:
                        result_msg = f"❌ Fake News ({confidence:.2f}% confidence)"
                        st.markdown(
                            f'<div class="result-box fake-result">{result_msg}</div>',
                            unsafe_allow_html=True,
                        )
                        st.error("Potential misinformation detected.")

                    # Updated Related Articles Section with Card UI
                    st.markdown(
                        '<div class="suggested-links">Related Articles:</div>',
                        unsafe_allow_html=True,
                    )
                    if suggested_articles:
                        for article in suggested_articles:
                            st.markdown(
                                f"""
                                <div style="background: #333333; padding: 15px; border-radius: 10px; margin: 10px 0; box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);">
                                    <h3 style="color: #00d4ff; margin: 0; font-size: 1.2em;">{article['title']}</h3>
                                    <p style="color: #d0d0d0; font-size: 0.95em; margin: 5px 0;">
                                        {article['description']}
                                    </p>
                                    <a href="{article['url']}" target="_blank" style="color: #00d4ff; text-decoration: none; font-weight: bold;">
                                        Read More
                                    </a>
                                </div>
                                """,
                                unsafe_allow_html=True,
                            )
                    else:
                        st.markdown(
                            '<div style="color: #d0d0d0; font-size: 1.1em;">No related articles found.</div>',
                            unsafe_allow_html=True,
                        )
        else:
            st.markdown(
                '<div class="result-box warning-result">⚠️ Please enter an article to analyze</div>',
                unsafe_allow_html=True,
            )

# Footer
st.markdown(
    """
    <div class="footer">
        Powered by Streamlit & Machine Learning | © 2025 
    </div>
    """,
    unsafe_allow_html=True,
)
